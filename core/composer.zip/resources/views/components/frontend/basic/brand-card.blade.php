<a href="{{ $brand->shopLink() }}">
    <img src="{{ getImage(null) }}" data-src="{{ $brand->logo() }}" class="w-100 lazyload" alt="brand">
</a>
