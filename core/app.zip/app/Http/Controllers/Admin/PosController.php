<?php

namespace App\Http\Controllers\Admin;

use App\Constants\Status;
use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Branch;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\ProductBatch;
use App\Lib\ProductManager;
use App\Lib\StockManager;
use App\Models\Deposit;
use App\Support\BranchContext;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PosController extends Controller
{
    private ?bool $backorderSalesAllowed = null;

    private function allowsBackorderSales(): bool
    {
        if ($this->backorderSalesAllowed !== null) {
            return $this->backorderSalesAllowed;
        }

        $branchId = BranchContext::ownerId();
        $this->backorderSalesAllowed = $branchId !== null
            && (bool) Branch::whereKey($branchId)->value('allow_backorder_sales');

        return $this->backorderSalesAllowed;
    }

    private function posCustomerQuery()
    {
        return \App\Models\User::query()
            ->when(BranchContext::ownerId(), fn($query, $branchId) => $query->where('branch_id', $branchId));
    }

    private function posCustomerDueAmounts(array $userIds): array
    {
        if (empty($userIds)) {
            return [];
        }

        return Deposit::query()
            ->whereIn('user_id', $userIds)
            ->where('status', Status::PAYMENT_PENDING)
            ->where('method_code', 0)
            ->where('trx', 'like', 'POS-%-DUE-%')
            ->selectRaw('user_id, SUM(amount) as due_amount')
            ->groupBy('user_id')
            ->pluck('due_amount', 'user_id')
            ->map(fn($amount) => (float) $amount)
            ->all();
    }

    private function productPayload(Product $product): array
    {
        $stock = (int) ($product->in_stock ?? 0);
        $purchasePrice = (float) ($product->purchase_price ?? 0);

        if ($branchId = BranchContext::ownerId()) {
            $branchBatches = $product->batches()->where('branch_id', $branchId);
            $stock = (int) ($branchBatches
                ->selectRaw('SUM(CASE WHEN qty_received > qty_sold THEN qty_received - qty_sold ELSE 0 END) as available')
                ->value('available') ?? 0);
            $batch = $product->batches()
                ->where('branch_id', $branchId)
                ->whereRaw('qty_received > qty_sold')
                ->orderBy('purchased_at')
                ->orderBy('id')
                ->first();
            $purchasePrice = (float) ($batch?->purchase_price ?? 0);

            if ($this->allowsBackorderSales() && $purchasePrice <= 0) {
                $purchasePrice = (float) ($product->batches()
                    ->where('branch_id', $branchId)
                    ->orderByDesc('purchased_at')
                    ->orderByDesc('id')
                    ->value('purchase_price') ?? $product->getRawOriginal('purchase_price') ?? 0);
            }
        }

        return [
            'id' => $product->id,
            'name' => $product->name,
            'sku' => $product->sku,
            'regular_price' => $product->regular_price ?? null,
            'sale_price' => $product->sale_price ?? null,
            'wholesale_price' => $product->wholesale_price ?? null,
            'purchase_price' => $purchasePrice,
            'in_stock' => $stock,
            'stock' => $stock,
            'allow_backorder_sales' => $this->allowsBackorderSales(),
        ];
    }

    // POS main page
    public function Pos()
    {
        $pageTitle = 'Point of Sale';
        $allowBackorderSales = $this->allowsBackorderSales();
        return view('admin.pos.index', compact('pageTitle', 'allowBackorderSales'));
    }

    // Debug: Check if data exists
    public function debugData()
    {
        return response()->json([
            'products_count' => Product::count(),
            'users_count' => \App\Models\User::count(),
            'sample_products' => Product::limit(3)->get(['id', 'name', 'regular_price', 'sale_price']),
            'sample_users' => \App\Models\User::limit(3)->get(['id', 'name', 'email'])
        ]);
    }

    // Debug: Get batch tracking status
    public function debugBatchStatus()
    {
        $batches = ProductBatch::with('product:id,name')
            ->select('id', 'product_id', 'batch_no', 'qty_received', 'qty_sold', 'purchase_price', 'purchased_at')
            ->orderBy('id', 'desc')
            ->limit(20)
            ->get();

        $stockLogs = \App\Models\StockLog::with('product:id,name')
            ->select('id', 'product_id', 'batch_id', 'change_quantity', 'remark', 'description', 'order_id', 'created_at')
            ->orderBy('id', 'desc')
            ->limit(20)
            ->get();

        return response()->json([
            'status' => 'debug',
            'batches' => $batches,
            'stock_logs' => $stockLogs,
            'issues' => [
                'batches_with_qty_sold_zero' => ProductBatch::where('qty_sold', 0)->where('qty_received', '>', 0)->count(),
                'batches_total' => ProductBatch::count(),
                'stock_logs_with_minus' => \App\Models\StockLog::where('remark', '-')->count(),
                'stock_logs_total' => \App\Models\StockLog::count(),
            ]
        ]);
    }

    // Debug: Comprehensive stock management status
    public function debugStockManagement()
    {
        try {
            $products = Product::whereIn('id', [5183])->take(5)->get(); // Use real product IDs
            
            $stockSummaries = [];
            foreach ($products as $product) {
                /** @var Product $product */
                $stockSummaries[] = StockManager::getStockSummary($product);
            }

            // Get recent POS orders
            $recentOrders = Order::where('order_number', 'like', 'POS-%')
                ->orderBy('id', 'desc')
                ->limit(10)
                ->with('orderDetails')
                ->get()
                ->map(function ($order) {
                    return [
                        'id' => $order->id,
                        'order_number' => $order->order_number,
                        'total' => $order->total_amount,
                        'profit' => $order->profit,
                        'items_count' => $order->orderDetails->count(),
                        'created_at' => $order->created_at
                    ];
                });

            return response()->json([
                'status' => 'stock_management_debug',
                'stock_summaries' => $stockSummaries,
                'recent_pos_orders' => $recentOrders,
                'system_stats' => [
                    'total_products' => Product::count(),
                    'total_batches' => ProductBatch::count(),
                    'total_stock_logs' => \App\Models\StockLog::count(),
                    'batches_with_qty_sold' => ProductBatch::where('qty_sold', '>', 0)->count(),
                    'stock_logs_deductions' => \App\Models\StockLog::where('remark', '-')->count()
                ]
            ]);
        } catch (\Throwable $e) {
            return response()->json([
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ], 500);
        }
    }

    // AJAX: Get paginated products
    public function getProducts(Request $request)
    {
        $page = (int) $request->query('page', 1);
        $perPage = (int) $request->query('per_page', 20);
        $offset = ($page - 1) * $perPage;

        $productQuery = Product::query();
        if (BranchContext::ownerId() === null) {
            $productQuery->whereNotNull('purchase_price')->where('purchase_price', '>', 0);
        }
        $totalProducts = (clone $productQuery)->count();
        $totalPages = ceil($totalProducts / $perPage);

        // Fetch products with pagination (include brand relationship)
        $products = $productQuery->with('brand')
            ->offset($offset)
            ->limit($perPage)
            ->orderBy('id', 'desc')
            ->get()
            ->map(function (Product $product) {
                return array_merge($this->productPayload($product), [
                    'brand_name' => $product->brand?->name ?? null,
                ]);
            });

        return response()->json([
            'products' => $products,
            'pagination' => [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'total_items' => $totalProducts,
                'per_page' => $perPage
            ]
        ]);
    }

    // AJAX: Get product by ID
    public function getProductById($id)
    {
        try {
            $product = Product::with('brand')->find($id);
            if (!$product) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'Product not found'
                ], 404);
            }

            return response()->json([
                'status' => 'success',
                'product' => array_merge($this->productPayload($product), [
                    'brand_name' => $product->brand?->name ?? null,
                ])
            ]);
        } catch (\Throwable $e) {
            \Log::error('getProductById error: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'message' => 'Error fetching product: ' . $e->getMessage()
            ], 500);
        }
    }

    // AJAX: Search products
    public function searchProducts(Request $request)
    {
        $query = trim($request->input('query', $request->query('query', '')));
        $exact = $request->boolean('exact');

        if ($query === '' || (!$exact && strlen($query) < 2)) {
            return response()->json([]);
        }

        $products = Product::with('brand')
            ->when(BranchContext::ownerId() === null, function ($products) {
                $products->whereNotNull('purchase_price')->where('purchase_price', '>', 0);
            })
            ->where(function ($q) use ($query, $exact) {
                if ($exact) {
                    $q->where('sku', $query);
                    return;
                }

                $q->where('name', 'like', "%{$query}%")
                    ->orWhere('sku', 'like', "%{$query}%");
            })
            ->orderBy('id', 'desc')
            ->limit(120)
            ->get()
            ->map(function (Product $product) {
                return array_merge($this->productPayload($product), [
                    'brand_name' => $product->brand?->name ?? null,
                ]);
            });

        return response()->json($products);
    }

    // AJAX: Add product to cart session
    public function addToCart(Request $request)
    {
        $product = Product::findOrFail($request->product_id);
        $productData = $this->productPayload($product);
        if (
            (!$this->allowsBackorderSales() && (float) $productData['purchase_price'] <= 0)
            || (BranchContext::ownerId() !== null && !$this->allowsBackorderSales() && $productData['in_stock'] < 1)
        ) {
            return response()->json([
                'status' => 'error',
            'message' => 'This product has no sellable stock in your branch.',
            ], 422);
        }
        $cart = session()->get('pos_cart', []);

        if (isset($cart[$product->id])) {
            $cart[$product->id]['quantity']++;
        } else {
            $cart[$product->id] = [
                'name' => $product->name,
                'price' => $product->sale_price ?? $product->regular_price ?? 0,
                'wholesale_price' => $product->wholesale_price ?? null,
                'quantity' => 1,
            ];
        }

        session()->put('pos_cart', $cart);
        return response()->json(['cart' => $cart]);
    }

    // AJAX: Remove product from cart
    public function removeFromCart(Request $request)
    {
        $cart = session()->get('pos_cart', []);
        if (isset($cart[$request->product_id])) {
            unset($cart[$request->product_id]);
            session()->put('pos_cart', $cart);
        }
        return response()->json(['cart' => $cart]);
    }

    // AJAX: Update product quantity
    public function updateQty(Request $request)
    {
        $cart = session()->get('pos_cart', []);
        $productId = $request->product_id;
        $action = $request->action;

        if (isset($cart[$productId])) {
            if ($action === 'increment') {
                $cart[$productId]['quantity']++;
            } elseif ($action === 'decrement') {
                if ($cart[$productId]['quantity'] > 1) {
                    $cart[$productId]['quantity']--;
                } else {
                    // Remove if quantity becomes 0
                    unset($cart[$productId]);
                }
            }
            session()->put('pos_cart', $cart);
        }

        return response()->json(['cart' => $cart]);
    }

    public function updateQtyDirect(Request $request)
    {
        $request->validate([
            'product_id' => 'required|numeric',
            'quantity' => 'required|numeric|min:1|max:9999'
        ]);

        $cart = session()->get('pos_cart', []);
        $productId = $request->product_id;
        $newQuantity = (int) $request->quantity;

        if (isset($cart[$productId])) {
            if ($newQuantity < 1) {
                // Remove if quantity is less than 1
                unset($cart[$productId]);
            } else {
                // Set the quantity directly
                $cart[$productId]['quantity'] = $newQuantity;
            }
            session()->put('pos_cart', $cart);
        }

        return response()->json(['cart' => $cart]);
    }

    // AJAX: Get current cart
    public function getCart()
    {
        $cart = session()->get('pos_cart', []);
        return response()->json(['cart' => $cart]);
    }

    // AJAX: Clear cart
    public function clearCart()
    {
        session()->forget('pos_cart');
        return response()->json(['cart' => []]);
    }

    // AJAX: Get selected customer (if any)
    public function getSelectedCustomer()
    {
        $id = session('pos_customer');
        if (!$id) {
            return response()->json(['customer' => null]);
        }
        $customer = $this->posCustomerQuery()->find($id);
        if (!$customer) {
            session()->forget('pos_customer');
            return response()->json(['customer' => null]);
        }

        $customerName = $customer->name;
        if (!$customerName && isset($customer->firstname, $customer->lastname)) {
            $customerName = trim($customer->firstname . ' ' . $customer->lastname);
        }
        if (!$customerName) {
            $customerName = $customer->email ?? 'Customer';
        }

        return response()->json(['customer' => [
            'id' => $customer->id,
            'name' => $customerName,
            'email' => $customer->email ?? null,
            'mobile' => $customer->mobile ?? null,
            'due_amount' => $this->posCustomerDueAmounts([$customer->id])[$customer->id] ?? 0,
        ]]);
    }

    // AJAX: Search customers (robust to different schema variants)
    public function searchCustomers(Request $request)
    {
        $q = trim($request->input('query', ''));
        if (strlen($q) < 2) {
            return response()->json([]);
        }

        try {
            $hasName = \Illuminate\Support\Facades\Schema::hasColumn('users', 'name');
            $hasFirstname = \Illuminate\Support\Facades\Schema::hasColumn('users', 'firstname');
            $hasLastname = \Illuminate\Support\Facades\Schema::hasColumn('users', 'lastname');
            $hasUsername = \Illuminate\Support\Facades\Schema::hasColumn('users', 'username');
            $mobileColumn = null;
            if (\Illuminate\Support\Facades\Schema::hasColumn('users', 'mobile')) {
                $mobileColumn = 'mobile';
            } elseif (\Illuminate\Support\Facades\Schema::hasColumn('users', 'phone')) {
                $mobileColumn = 'phone';
            }

            $qb = $this->posCustomerQuery()->where(function ($criteria) use ($q, $hasName, $hasFirstname, $hasLastname, $hasUsername, $mobileColumn) {
                if ($hasName) {
                    $criteria->where('name', 'like', "%{$q}%");
                } elseif ($hasFirstname && $hasLastname) {
                    $criteria->whereRaw("CONCAT(firstname, ' ', lastname) like ?", ["%{$q}%"]);
                } elseif ($hasUsername) {
                    $criteria->where('username', 'like', "%{$q}%");
                } else {
                    $criteria->where('email', 'like', "%{$q}%");
                }

                $criteria->orWhere('email', 'like', "%{$q}%");
                if ($mobileColumn) {
                    $criteria->orWhere($mobileColumn, 'like', "%{$q}%");
                }
            });

            $users = $qb->limit(10)->get();
            $dueAmounts = $this->posCustomerDueAmounts($users->pluck('id')->all());

            $result = $users->map(function ($u) use ($hasName, $hasFirstname, $hasLastname, $hasUsername, $mobileColumn, $dueAmounts) {
                if ($hasName) {
                    $name = $u->name;
                } elseif ($hasFirstname && $hasLastname) {
                    $name = trim(($u->firstname ?? '') . ' ' . ($u->lastname ?? '')) ?: ($u->email ?? '');
                } elseif ($hasUsername) {
                    $name = $u->username ?? $u->email;
                } else {
                    $name = $u->email ?? 'User';
                }
                return [
                    'id' => $u->id,
                    'name' => $name,
                    'email' => $u->email ?? null,
                    'mobile' => $mobileColumn ? ($u->{$mobileColumn} ?? null) : null,
                    'due_amount' => $dueAmounts[$u->id] ?? 0,
                ];
            });

            return response()->json($result);
        } catch (\Throwable $e) {
            // Log and return empty set when DB schema unexpected
            \Log::error('Customer search error: ' . $e->getMessage());
            return response()->json([]);
        }
    }

    // AJAX: Create a quick customer and select
    public function createCustomer(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'mobile' => 'required|string|max:50',
        ]);

        try {
            // Split name into firstname and lastname
            $fullName = trim($validated['name']);
            $nameParts = explode(' ', $fullName, 2);
            $firstname = $nameParts[0] ?? '';
            $lastname = isset($nameParts[1]) ? $nameParts[1] : '';

            $password = bcrypt($validated['mobile']);

            $data = [
                'firstname' => $firstname,
                'lastname' => $lastname,
                'email' => $request->email ?? null,
                'mobile' => $validated['mobile'],
                'address' => $request->address ?? null,
                'password' => $password,
                'status' => Status::USER_ACTIVE ?? 1,
                'ev' => Status::VERIFIED ?? 1,
                'sv' => Status::VERIFIED ?? 1,
            ];

            $user = \App\Models\User::create($data);
            session()->put('pos_customer', $user->id);

            $customerName = trim(($user->firstname ?? '') . ' ' . ($user->lastname ?? ''));
            if (!$customerName) {
                $customerName = $user->email ?? 'Customer';
            }

            return response()->json(['customer' => [
                'id' => $user->id,
                'name' => $customerName,
                'email' => $user->email ?? null,
                'mobile' => $user->mobile ?? null,
                'due_amount' => $this->posCustomerDueAmounts([$user->id])[$user->id] ?? 0,
            ]]);
        } catch (\Exception $e) {
            \Log::error('POS Create Customer Error: ' . $e->getMessage());
            return response()->json(['message' => 'Error creating customer: ' . $e->getMessage()], 422);
        }
    }

    // AJAX: Select customer (store in session)
    public function selectCustomer(Request $request)
    {
        $user = $this->posCustomerQuery()->findOrFail($request->user_id);
        session()->put('pos_customer', $user->id);

        $customerName = $user->name;
        if (!$customerName && isset($user->firstname, $user->lastname)) {
            $customerName = trim($user->firstname . ' ' . $user->lastname);
        }
        if (!$customerName) {
            $customerName = $user->email ?? 'Customer';
        }

        return response()->json(['customer' => [
            'id' => $user->id,
            'name' => $customerName,
            'email' => $user->email ?? null,
            'mobile' => $user->mobile ?? null,
            'due_amount' => $this->posCustomerDueAmounts([$user->id])[$user->id] ?? 0,
        ]]);
    }

    // AJAX: Clear selected customer
    public function clearSelectedCustomer()
    {
        session()->forget('pos_customer');
        return response()->json(['customer' => null]);
    }

    // AJAX: Confirm order (uses cart from frontend)
    public function confirmOrder(Request $request)
    {
        \Log::info('POS confirmOrder called', [
            'method' => $request->method(),
            'content_type' => $request->header('Content-Type'),
            'all_input' => $request->all()
        ]);

        // Get cart from frontend request (not from session)
        $cartData = $request->input('cart', []);
        $priceType = $request->input('price_type', 'regular');
        
        // If cart is empty, get from session (fallback)
        if (empty($cartData)) {
            $cartData = session()->get('pos_cart', []);
        }
        
        \Log::info('Cart data received:', ['cart' => $cartData, 'price_type' => $priceType]);
        
        if (empty($cartData)) {
            \Log::warning('POS order failed: empty cart');
            return response()->json([
                'status' => 'error',
                'message' => 'Cart is empty'
            ], 400);
        }

        // Normalize cart data (convert from frontend format if needed)
        $cart = [];
        $orderedCart = [];
        $sequence = 0;
        foreach ($cartData as $key => $item) {
            if (!is_array($item)) {
                continue;
            }

            $sequence++;
            $productId = $item['product_id'] ?? $item['id'] ?? $key;
            if (!$productId) {
                continue;
            }

            $regularPrice = isset($item['regular_price']) ? (float)$item['regular_price'] : (float)($item['price'] ?? 0);
            $salePrice = isset($item['sale_price']) ? (float)$item['sale_price'] : 0;
            $wholesalePrice = isset($item['wholesale_price']) ? (float)$item['wholesale_price'] : 0;

            $price = $regularPrice;
            if ($priceType === 'wholesale' && $wholesalePrice > 0) {
                $price = $wholesalePrice;
            } elseif ($priceType === 'sale' && $salePrice > 0) {
                $price = $salePrice;
            } elseif (isset($item['price']) && (float)$item['price'] > 0) {
                $price = (float)$item['price'];
            }

            $quantity = (int)($item['quantity'] ?? 1);
            if ($quantity < 1) {
                $quantity = 1;
            }

            $normalizedItem = [
                'product_id' => $productId,
                'name' => $item['name'] ?? '',
                'sku' => $item['sku'] ?? null,
                'price' => $price,
                'regular_price' => $regularPrice,
                'sale_price' => $salePrice,
                'wholesale_price' => $wholesalePrice,
                'quantity' => $quantity,
                'sort_order' => isset($item['sort_order']) ? (int)$item['sort_order'] : $sequence,
            ];

            $cart[$productId] = $normalizedItem;
            $orderedCart[] = $normalizedItem;
        }

        usort($orderedCart, function ($first, $second) {
            $firstOrder = (int)($first['sort_order'] ?? 0);
            $secondOrder = (int)($second['sort_order'] ?? 0);

            if ($firstOrder === $secondOrder) {
                return 0;
            }

            return $firstOrder < $secondOrder ? -1 : 1;
        });

        \Log::info('Normalized cart:', ['cart' => $cart]);
        
        if (empty($orderedCart)) {
            \Log::warning('POS order failed: no valid items in cart');
            return response()->json([
                'status' => 'error',
                'message' => 'No valid items in cart'
            ], 400);
        }

        // Snapshot cart items + customer
        $cartSnapshot = $orderedCart;
        $customerId = session('pos_customer');
        if ($customerId && !$this->posCustomerQuery()->whereKey($customerId)->exists()) {
            session()->forget('pos_customer');
            $customerId = null;
        }
        $customerName = 'Walk-in Customer';
        if ($customerId) {
            $customer = $this->posCustomerQuery()->find($customerId);
            if ($customer) {
                $customerName = $customer->name;
                if (!$customerName && isset($customer->firstname, $customer->lastname)) {
                    $customerName = trim($customer->firstname . ' ' . $customer->lastname);
                }
                if (!$customerName) {
                    $customerName = $customer->email ?? 'Walk-in Customer';
                }
            }
        }

        $discountType = $request->input('discount_type'); // 'percentage' or 'fixed'
        $discountAmount = floatval($request->input('discount_amount', 0));

        $expectedSubtotal = 0;
        foreach ($orderedCart as $item) {
            $useWholesale = ($priceType === 'wholesale') && !empty($item['wholesale_price']);
            $unitPrice = $useWholesale ? (float)$item['wholesale_price'] : (float)($item['price'] ?? $item['regular_price'] ?? 0);
            $expectedSubtotal += $unitPrice * $item['quantity'];
        }
        $expectedDiscount = 0;
        if ($discountType === 'percentage' && $discountAmount > 0) {
            $expectedDiscount = ($expectedSubtotal * $discountAmount) / 100;
        } elseif ($discountType === 'fixed' && $discountAmount > 0) {
            $expectedDiscount = min($discountAmount, $expectedSubtotal);
        }
        $expectedTotal = round($expectedSubtotal - $expectedDiscount, 2);
        $request->validate([
            'paid_amount' => ['sometimes', 'required', 'numeric', 'min:0', 'max:' . $expectedTotal],
        ]);
        $paidAmount = round((float)$request->input('paid_amount', $expectedTotal), 2);

        if ($paidAmount < $expectedTotal && !$this->posCustomerQuery()->whereKey(session('pos_customer'))->exists()) {
            return response()->json([
                'status' => 'error',
                'message' => 'Assign a customer before recording partial payment or due.',
            ], 422);
        }

        $order = null;
        $productManager = new ProductManager();
        
        try {
            DB::transaction(function () use ($orderedCart, &$order, $priceType, $discountType, $discountAmount, $paidAmount, $productManager) {
                $productIds = array_values(array_unique(array_column($orderedCart, 'product_id')));
                $products = Product::whereIn('id', $productIds)->lockForUpdate()->get()->keyBy('id');

                foreach ($orderedCart as $item) {
                    $product = $products->get($item['product_id']);
                    if (!$product) {
                        throw new \Exception('Product not found: ID ' . $item['product_id']);
                    }
                    if (BranchContext::ownerId() !== null && !$this->allowsBackorderSales()) {
                        $batchCanCoverOrder = ProductBatch::where('product_id', $product->id)
                            ->where('branch_id', BranchContext::ownerId())
                            ->whereRaw('qty_received >= qty_sold + ?', [$item['quantity']])
                            ->where('purchase_price', '>', 0)
                            ->exists();
                        if (!$batchCanCoverOrder) {
                            throw new \Exception('Insufficient stock in your branch for ' . $product->name . '.');
                        }
                    } elseif (
                        BranchContext::ownerId() === null
                        && (float) ($product->getRawOriginal('purchase_price') ?? 0) <= 0
                    ) {
                        throw new \Exception('Purchase price is required before selling ' . $product->name . '.');
                    }
                }

                $subtotal = 0;
                $totalCost = 0;
                foreach ($orderedCart as $item) {
                    $useWholesale = ($priceType === 'wholesale') && !empty($item['wholesale_price']);
                    $unitPrice    = $useWholesale ? (float)$item['wholesale_price'] : (float)($item['price'] ?? $item['regular_price'] ?? 0);
                    $subtotal += $unitPrice * $item['quantity'];
                }

                // Calculate discount
                $actualDiscount = 0;
                if ($discountType === 'percentage' && $discountAmount > 0) {
                    $actualDiscount = ($subtotal * $discountAmount) / 100;
                } elseif ($discountType === 'fixed' && $discountAmount > 0) {
                    $actualDiscount = min($discountAmount, $subtotal);
                }

                $total = $subtotal - $actualDiscount;

                // Attach customer if selected
                $customerId = session('pos_customer');

                // Create order (delivered by default)
                $order = Order::create([
                    'order_number'   => 'POS-' . time(),
                    'user_id'        => $customerId ?? null,
                    'status'         => Status::ORDER_DELIVERED,
                    'total_amount'   => $total,
                    'cost_amount'    => 0, // Will be updated after processing items
                    'profit'         => 0, // Will be updated after processing items
                    'payment_status' => $paidAmount >= round($total, 2) ? Status::PAYMENT_SUCCESS : Status::PAYMENT_PENDING,
                    'is_cod'         => true,
                ]);

                // Create order items with batch tracking and profit calculation
                foreach ($orderedCart as $item) {
                    $productId = $item['product_id'] ?? $item['id'] ?? null;
                    if (!$productId) {
                        continue;
                    }

                    $product = $products->get($productId);
                    if (!$product) {
                        throw new \Exception("Product not found: ID {$productId}");
                    }

                    $useWholesale = ($priceType === 'wholesale') && !empty($item['wholesale_price']);
                    $unitPrice    = $useWholesale ? (float)$item['wholesale_price'] : (float)($item['price'] ?? $item['regular_price'] ?? 0);

                    // Distribute discount proportionally across items
                    $itemSubtotal = $unitPrice * $item['quantity'];
                    $itemDiscount = ($itemSubtotal / $subtotal) * $actualDiscount;

                    // Get best batch for this product (FIFO)
                    $batchData = $productManager->getBestBatchForSale($product, $item['quantity']);
                    
                    // If no batch found, try fallback: get ANY available batch
                    if (!$batchData) {
                        if (BranchContext::ownerId() !== null && !$this->allowsBackorderSales()) {
                            throw new \Exception('Insufficient stock in your branch for ' . $product->name . '.');
                        }

                        $anyBatch = ProductBatch::where('product_id', $productId)
                            ->when(BranchContext::ownerId(), fn($query, $branchId) => $query->where('branch_id', $branchId))
                            ->where('qty_received', '>', DB::raw('qty_sold'))
                            ->orderBy('purchased_at', 'asc')
                            ->orderBy('id', 'asc')
                            ->first();

                        if (!$anyBatch && $this->allowsBackorderSales()) {
                            $anyBatch = ProductBatch::where('product_id', $productId)
                                ->where('branch_id', BranchContext::ownerId())
                                ->orderByDesc('purchased_at')
                                ->orderByDesc('id')
                                ->first();
                        }
                        
                        if ($anyBatch) {
                            $purchasePrice = (float)($anyBatch->purchase_price ?? 0);
                            if ($purchasePrice <= 0) {
                                $purchasePrice = (float) ($product->getRawOriginal('purchase_price') ?? 0);
                            }
                            $batchId = $anyBatch->id;
                            \Log::info("Using fallback batch {$anyBatch->batch_no} for product {$productId}");
                        } else {
                            // No batch at all - use the validated product purchase price.
                            $purchasePrice = (float) $product->purchase_price;
                            $batchId = null;
                            \Log::warning("No batch found for product {$productId}, using product purchase_price: {$purchasePrice}");
                        }
                    } else {
                        $purchasePrice = (float) ($batchData['purchase_price'] ?? 0);
                        if ($purchasePrice <= 0) {
                            if (BranchContext::ownerId() !== null && !$this->allowsBackorderSales()) {
                                throw new \Exception('The selected branch batch has no purchase cost for ' . $product->name . '.');
                            }
                            $purchasePrice = (float) ($product->getRawOriginal('purchase_price') ?? 0);
                        }
                        $batchId = $batchData['batch_id'];
                    }

                    // Calculate profit for this item
                    $itemProfit = ($unitPrice - $purchasePrice) * $item['quantity'];

                    // Create order detail with profit tracking
                    $orderDetail = OrderDetail::create([
                        'order_id'           => $order->id,
                        'product_id'         => $productId,
                        'product_variant_id' => 0,
                        'quantity'           => $item['quantity'],
                        'price'              => $unitPrice,
                        'discount'           => round($itemDiscount, 2),
                        'purchase_price'     => $purchasePrice,
                        'batch_id'           => $batchId,
                        'profit'             => round($itemProfit, 2),
                    ]);

                    // ✅ COMPREHENSIVE STOCK DEDUCTION - Always deduct from all products
                    // This is the primary stock management point for POS sales
                    try {
                        $deductResult = StockManager::deductStock($product, $item['quantity'], [
                            'batch_id' => $batchId,
                            'order_id' => $order->id,
                            'description' => "POS Sale - Qty: {$item['quantity']}" . ($batchId ? " (Batch ID: {$batchId})" : ""),
                            'variant' => null,
                            'allow_backorder' => $this->allowsBackorderSales(),
                        ]);

                        if ($deductResult['success']) {
                            \Log::info("✅ Stock successfully deducted", [
                                'product_id' => $product->id,
                                'product_name' => $product->name,
                                'quantity' => $item['quantity'],
                                'remaining_stock' => $deductResult['remaining_stock'],
                                'batch_id' => $batchId
                            ]);
                        } else {
                            if (BranchContext::ownerId() !== null) {
                                throw new \Exception($deductResult['message']);
                            }
                            \Log::error("❌ Stock deduction encountered issue", [
                                'product_id' => $product->id,
                                'product_name' => $product->name,
                                'message' => $deductResult['message'],
                                'batch_id' => $batchId
                            ]);
                        }
                    } catch (\Throwable $e) {
                        \Log::error("❌ Stock deduction exception", [
                            'product_id' => $product->id,
                            'error' => $e->getMessage(),
                            'batch_id' => $batchId
                        ]);
                    }

                    // Track total cost for order
                    $totalCost += $purchasePrice * $item['quantity'];
                }

                // Update order with cost and profit
                $orderProfit = $total - $totalCost;
                $order->update([
                    'cost_amount' => round($totalCost, 2),
                    'profit'      => round($orderProfit, 2),
                ]);

                // Record received payment and any remaining balance separately.
                $paymentEntries = [];
                if ($paidAmount > 0) {
                    $paymentEntries[] = ['amount' => $paidAmount, 'status' => Status::PAYMENT_SUCCESS, 'suffix' => 'PAID'];
                }
                $dueAmount = round($total - $paidAmount, 2);
                if ($dueAmount > 0) {
                    $paymentEntries[] = ['amount' => $dueAmount, 'status' => Status::PAYMENT_PENDING, 'suffix' => 'DUE'];
                }

                foreach ($paymentEntries as $paymentEntry) {
                    $deposit = new Deposit();
                    $deposit->user_id = $customerId ?? null;
                    $deposit->order_id = $order->id;
                    $deposit->amount = $paymentEntry['amount'];
                    $deposit->method_code = 0; // POS/manual
                    $deposit->method_currency = gs('cur_text');
                    $deposit->trx = 'POS-' . $order->id . '-' . $paymentEntry['suffix'] . '-' . time();
                    $deposit->status = $paymentEntry['status'];
                    $deposit->save();
                }

                // Clear cart + selected customer
                session()->forget('pos_cart');
                session()->forget('pos_customer');
            });
        } catch (\Throwable $e) {
            \Log::error('POS order creation failed: ' . $e->getMessage(), [
                'trace' => $e->getTraceAsString(),
                'cart' => $cart,
                'price_type' => $priceType,
                'discount_type' => $discountType,
                'discount_amount' => $discountAmount
            ]);
            
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to create order: ' . $e->getMessage()
            ], 500);
        }
        
        // If order was not created, return error
        if (!$order) {
            \Log::error('POS order creation failed: order object is null');
            return response()->json([
                'status' => 'error',
                'message' => 'Order creation failed - unknown error'
            ], 500);
        }

        // Build invoice items array
        $invoiceItems = [];
        $totalQty = 0;
        $subtotal = 0;
        $invoiceSnapshot = $cartSnapshot;
        usort($invoiceSnapshot, function ($first, $second) {
            $firstOrder = (int)($first['sort_order'] ?? 0);
            $secondOrder = (int)($second['sort_order'] ?? 0);

            if ($firstOrder === $secondOrder) {
                return 0;
            }

            return $firstOrder < $secondOrder ? -1 : 1;
        });

        foreach ($invoiceSnapshot as $item) {
            $productId = $item['product_id'] ?? $item['id'] ?? null;
            $useWholesale = ($priceType === 'wholesale') && !empty($item['wholesale_price']);
            $unitPrice    = $useWholesale ? (float)$item['wholesale_price'] : (float)($item['price'] ?? $item['regular_price'] ?? 0);
            $itemTotal = $unitPrice * $item['quantity'];
            $subtotal += $itemTotal;
            $invoiceItems[] = [
                'name'     => $item['name'],
                'qty'      => $item['quantity'],
                'price'    => $unitPrice,
                'total'    => $itemTotal,
            ];
            $totalQty += $item['quantity'];
        }

        // Calculate final discount for display
        $displayDiscount = 0;
        if ($discountType === 'percentage' && $discountAmount > 0) {
            $displayDiscount = ($subtotal * $discountAmount) / 100;
        } elseif ($discountType === 'fixed' && $discountAmount > 0) {
            $displayDiscount = min($discountAmount, $subtotal);
        }

        \Log::info('POS order created successfully', [
            'order_id' => $order->id,
            'order_number' => $order->order_number,
            'subtotal' => $subtotal,
            'discount' => $displayDiscount,
            'total' => $order->total_amount,
            'cost' => $order->cost_amount,
            'profit' => $order->profit,
        ]);

        return response()->json([
            'status'  => 'success',
            'message' => 'POS Order Confirmed Successfully! Order #' . $order->order_number,
            'order_id' => $order->id,
            'order_number' => $order->order_number,
            'total_amount' => $order->total_amount,
            'paid_amount' => $paidAmount,
            'due_amount' => round($order->total_amount - $paidAmount, 2),
            'cost_amount' => $order->cost_amount,
            'profit' => $order->profit,
            'invoice' => [
                'order_id'      => $order->id,
                'store_name'    => gs('site_name') ?? 'Store',
                'store_address' => gs('address') ?? gs('support_address') ?? 'Address not set',
                'store_phone'   => gs('phone_number') ?? gs('support_phone') ?? 'Phone not set',
                'currency_sym'  => gs('cur_sym') ?? '$',
                'order_number'  => $order->order_number,
                'date'          => now()->format('d-m-Y H:i:s'),
                'customer_name' => $customerName,
                'items'         => $invoiceItems,
                'subtotal'      => $subtotal,
                'discount'      => $displayDiscount,
                'total_qty'     => $totalQty,
                'grand_total'   => $order->total_amount,
                'cost'          => $order->cost_amount,
                'profit'        => $order->profit,
                'sold_by'       => auth()->guard('admin')->user()->name ?? 'Admin',
            ],
        ]);
    }
}
